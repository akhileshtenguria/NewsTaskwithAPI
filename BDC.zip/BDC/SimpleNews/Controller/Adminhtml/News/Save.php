<?php

namespace BDC\SimpleNews\Controller\Adminhtml\News;

use BDC\SimpleNews\Controller\Adminhtml\News;
use Magento\Framework\Filesystem;
 use Magento\Framework\Registry;
 use Magento\Framework\View\Result\PageFactory;
 use BDC\SimpleNews\Model\NewsFactory;
use Magento\MediaStorage\Model\File\UploaderFactory;

class Save extends News
{
   /**
     * @return void
     */

   /**
     * FileSystem
     *
     * @var \Magento\Framework\Filesystem
     */
    public $filesystem;

   /**
     * UploaderFactory
     *
     * @var \Magento\MediaStorage\Model\File\UploaderFactory
     */

    public $uploaderfactory;


    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        Filesystem $fileSystem,
        UploaderFactory $uploaderfactory,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        NewsFactory $newsFactory
    ) {
        $this->filesystem = $fileSystem;
        $this->uploaderfactory = $uploaderfactory;
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_newsFactory = $newsFactory;
        parent::__construct($context,$coreRegistry, $resultPageFactory, $newsFactory);
    }

   public function execute()
   {
      $isPost = $this->getRequest()->getPost();

      if ($isPost) {
         $newsModel = $this->_newsFactory->create();
         $newsId = $this->getRequest()->getParam('id');

         if ($newsId) {
            $newsModel->load($newsId);

         }
         $formData = $this->getRequest()->getParam('news');
         
         // Image Save code
         $mediaDirectory = $this->filesystem->getDirectoryRead(
            \Magento\Framework\App\Filesystem\DirectoryList::MEDIA
        );
         $baseimageMediapath="news/events/images/";
         $profileImage = $this->getRequest()->getFiles('news');
         // print_r($profileImage['newsevents_image']); die; 
        if ($profileImage['newsevents_image']['type'] == "image/jpeg") {
            $imageField = 'newsevents_image';
            /* prepare banner image */
            if (isset($profileImage[$imageField]) && isset($profileImage[$imageField]['name'])) {
                if (isset($profileImage[$imageField]['delete'])) {
                    unlink($mediaDirectory->getAbsolutePath() . $profileImage[$imageField]['name']);
                    $newsModel->setData($imageField, '');
                } else {
                    $newsModel->setData($imageField, $profileImage[$imageField]['name']);
                }
            }
            try {
                $uploader =$this->uploaderfactory;
                $uploader = $uploader->create(['fileId' => 'news[newsevents_image]']);
                $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                $uploader->setAllowRenameFiles(true);
                $uploader->setFilesDispersion(true);
                $uploader->setAllowCreateFolders(true);
                $result = $uploader->save(
                    $mediaDirectory->getAbsolutePath($baseimageMediapath)
                );
                // print_r($result['name']);
                // die; 
                $formData['newsevents_image']= $baseimageMediapath . $result['name'];
                $newsModel->setData(
                    'newsevents_image',
                    $baseimageMediapath . $result['name']
                );
            } catch (\Exception $e) {
                if ($e->getCode() != \Magento\Framework\File\Uploader::TMP_NAME_EMPTY) {
                    $this->messageManager->addExceptionMessage(
                        $e,
                        __('Please Insert Image of types jpg, jpeg, gif, png')
                    );
                }
            }
        } else {
         echo "Test"; 
            $newsModel->setData('newsevents_image', '');
        }
        // print_r($formData);
        // die;
         $newsModel->setData($formData);

         try {
            // Save news
            $newsModel->save();

            // Display success message
            $this->messageManager->addSuccess(__('The news has been saved.'));

            // Check if 'Save and Continue'
            if ($this->getRequest()->getParam('back')) {
               $this->_redirect('*/*/edit', ['id' => $newsModel->getId(), '_current' => true]);
               return;
            }

            // Go to grid page
            $this->_redirect('*/*/');
            return;
         } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
         }

         $this->_getSession()->setFormData($formData);
         $this->_redirect('*/*/edit', ['id' => $newsId]);
      }
   }
}
